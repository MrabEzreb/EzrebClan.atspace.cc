MrabEzreb.github.io
===================
NOTICE: Because HTML is classified as a markup language, and is thus not included when getting the percentages of the languages, I have forced github to classify HTML files as WebIDL, whatever that is :P
===================
This should work to do what I want. Basically, you should be able to calculate the delta-v of various maneuvers in kerbal space program.
