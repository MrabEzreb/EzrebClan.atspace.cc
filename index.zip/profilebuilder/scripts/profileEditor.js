var $ = window.$;
function getEditor() {
    "use strict";
    return document.getElementsByTagName("profileEditor")[0];
}