function myFunc() {
    "use strict";
    document.getElementById('demo').innerHTML = "Hello World!";
}